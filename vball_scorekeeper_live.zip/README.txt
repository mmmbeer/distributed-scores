VBall Scorekeeper

Upload all files to:
https://vball.fairway3games.com/

Pages:
- /index.html or / = scorekeeper
- /viewer.html = viewer scoreboard

The viewer continuously pulls the latest score from api.php.
Polling speed:
- Active tab: every 250ms
- Background tab: every 1000ms

Make sure /data is writable by PHP if your host does not allow PHP to create it automatically.
