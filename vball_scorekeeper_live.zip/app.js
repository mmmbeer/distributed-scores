let state = null;
let saveTimer = null;

const $ = id => document.getElementById(id);

async function loadState() {
  const res = await fetch(`api.php?ts=${Date.now()}`, { cache: "no-store" });
  state = await res.json();
  render();
}

async function saveState(patch = {}) {
  state = { ...state, ...patch };
  render();

  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const res = await fetch("api.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
      body: JSON.stringify(state)
    });

    state = await res.json();
    render();
  }, 80);
}

function render() {
  if (!state) return;

  $("leftTeam").value = state.leftTeam;
  $("rightTeam").value = state.rightTeam;
  $("leftScore").textContent = state.leftScore;
  $("rightScore").textContent = state.rightScore;
  $("leftGames").textContent = state.leftGames;
  $("rightGames").textContent = state.rightGames;
}

function changeScore(side, amount) {
  const key = side === "left" ? "leftScore" : "rightScore";
  saveState({ [key]: Math.max(0, Number(state[key]) + amount) });
}

function bindTouchZone(element, side) {
  let startX = 0;
  let startY = 0;
  let startedOnControl = false;

  element.addEventListener("pointerdown", event => {
    startedOnControl = Boolean(event.target.closest("button, input, a"));
    startX = event.clientX;
    startY = event.clientY;
  });

  element.addEventListener("pointerup", event => {
    if (startedOnControl) return;

    const dx = event.clientX - startX;
    const dy = event.clientY - startY;

    if (Math.abs(dy) > 48 && Math.abs(dy) > Math.abs(dx)) {
      changeScore(side, dy > 0 ? -1 : 1);
      return;
    }

    changeScore(side, 1);
  });
}

$("leftTeam").addEventListener("change", event => {
  saveState({ leftTeam: event.target.value || "Home" });
});

$("rightTeam").addEventListener("change", event => {
  saveState({ rightTeam: event.target.value || "Away" });
});

$("leftGame").addEventListener("click", event => {
  event.stopPropagation();
  saveState({ leftGames: Number(state.leftGames) + 1 });
});

$("rightGame").addEventListener("click", event => {
  event.stopPropagation();
  saveState({ rightGames: Number(state.rightGames) + 1 });
});

$("newSet").addEventListener("click", () => {
  saveState({
    leftScore: 0,
    rightScore: 0,
    setNumber: Number(state.setNumber) + 1
  });
});

$("resetMatch").addEventListener("click", () => {
  saveState({
    leftScore: 0,
    rightScore: 0,
    leftGames: 0,
    rightGames: 0,
    setNumber: 1
  });
});

bindTouchZone($("leftSide"), "left");
bindTouchZone($("rightSide"), "right");

loadState();
